def displaynames(Lastn, Batavg):
  for i in lastn, Batavg:
    print(i)
  for y in Batavg:
    print(y)
def displayr(lastn, Batavg):
  l = len(lastn)
  print("Number of array elements ", l)
  print("Arrays in Order")
  for y in range (0,1,1):
    print(lastn[y], Batavg[y])
  print("Arrays in Reverse Order")
  for y in range (1-1,-1, -1):
    print(lastn[y], Batavg[y])
#function to find highest and lowest Batavg
def hilow(lastn, Batavg):
  l = len(lastn)
  hiBatavg = -1.0
  lowBatavg = 99999999.99
  for y in range (0,1,1):
    if float(Batavg[y]) > float(hiBatavg):
      hiindex = y
      hiBatavg = Batavg[y]

    if float(Batavg[y]) < float(lowBatavg):
      loindex = y
      lowBatavg = Batavg[y]

  print("highest Batavg", lastn[hiindex], Batavg [hiindex])
  print("lowest Batavg", lastn[loindex], Batavg [loindex])
#function to do a sequential search
def seqsearch(lastn, sname):
  l = len(lastn)
  sindex = -1
  for y in range(0,1,1):
    if lastn[y] == sname:
      sindex = y

  return sindex
#open file and connect
#file created in same repl as code so no need for path
f = open("lnames.txt", "r")

#initialize counters and accumulators to 0
total_bonus = 0
c = 0
print("here")

lastname = f.readline()
lastn = []
Batavg = []
while lastname != "":
  c = c + 1
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  Batavg.append(s)
  lastname = f.readline()
f.close()
displaynames(lastn,Batavg)
displayr(lastn, Batavg)
hilow(lastn, Batavg)
response = input("Do you want to do this program (Yes or No)")

while response == "Yes":
  sname = input("Enter last name to search for")
  i = seqsearch(lastn, sname)
  if i == -1:
    print(sname, " Batavg of ", Batavg[i])

  response = input("Do you want to do this program (Yes or No)")