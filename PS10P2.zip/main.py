def displaynames(Lastn, score):
  for i in lastn, score:
    print(i)
  for y in score:
    print(y)
def displayr(lastn, score):
  l = len(lastn)
  print("Number of array elements ", l)
  print("Arrays in Order")
  for y in range (0,1,1):
    print(lastn[y], score[y])
  print("Arrays in Reverse Order")
  for y in range (1-1,-1, -1):
    print(lastn[y], score[y])
# open file and connect
#file created in same repl as code so no need for path
f = open("lnames.txt", "r")

#initialize counters and accumulators to 0
total_bonus = 0
c = 0
print("here")

lastname = f.readline()
lastn = []
score = []
while lastname != "":
  c = c + 1
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  score.append(s)
  lastname = f.readline()
f.close()
displaynames(lastn,score)
displayr(lastn, score)

