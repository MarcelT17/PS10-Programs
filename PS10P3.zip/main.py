def displaynames(Lastn, score):
  for i in lastn, score:
    print(i)
  for y in score:
    print(y)
def displayr(lastn, score):
  l = len(lastn)
  print("Number of array elements ", l)
  print("Arrays in Order")
  for y in range (0,1,1):
    print(lastn[y], score[y])
  print("Arrays in Reverse Order")
  for y in range (1-1,-1, -1):
    print(lastn[y], score[y])
#function to find highest and lowest score
def hilow(lastn, score):
  l = len(lastn)
  hiscore = -1.0
  lowscore = 99999999.99
  for y in range (0,1,1):
    if float(score[y]) > float(hiscore):
      hiindex = y
      hiscore = score[y]

    if float(score[y]) < float(lowscore):
      loindex = y
      lowscore = score[y]

  print("highest score", lastn[hiindex], score [hiindex])
  print("lowest score", lastn[loindex], score [loindex])
# open file and connect
  #file created in same repl as code so no need for path
f = open("lnames.txt", "r")

print("here")

lastname = f.readline()
lastn = []
score = []
while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  score.append(s)
  lastname = f.readline()
f.close()
#function call to display arrays
displaynames(lastn,score)
#function call to display arrays in reverse order
displayr(lastn, score)
#function call to find highest and lowest scores
hilow(lastn, score)
