def displaynames(Lastn):
  for i in lastn:
    print(i)
def displayr(lastn):
  l = len(lastn)
  print ("number of array elements ", l)
  print("Arrays in Order")
  for x in range(0,1,2):
    print(lastn[x])
  print("Arrays in Reverse Order")
  for y in range (1-1,-1, -1):
    print(lastn[x])
    # open file and connect
f = open("lnames.txt", "r")

f = open("lnames.txt", "r")

#initialize counters and accumulators to 0
total_bonus = 0
c = 0
print("here")

lastname = f.readline()
lastn = []

while lastname != "":
  c = c + 1
  lastn.append(str(lastname).rstrip("\n"))
  lastname = f.readline()
f.close()
displaynames(lastn)
displayr(lastn)